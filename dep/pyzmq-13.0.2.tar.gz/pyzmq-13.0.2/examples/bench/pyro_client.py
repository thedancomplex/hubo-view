import Pyro.core

client = Pyro.core.getProxyForURI("PYROLOC://localhost:7766/echo")